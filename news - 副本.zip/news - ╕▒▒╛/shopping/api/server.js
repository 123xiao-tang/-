const express = require('express');
const mysql = require('mysql2');
// 引入cors库，用于处理跨域请求，允许不同源的客户端访问服务器资源
const cors = require('cors');
// 引入path模块，用于处理文件路径相关操作
const path = require('path');
// 引入body-parser库，用于解析HTTP请求中的正文数据，如表单数据、JSON数据等
const bodyParser = require('body-parser');
// 引入jsonwebtoken库，用于处理JSON Web Tokens（JWT），常用于用户认证等场景
const jwt = require('jsonwebtoken');
// 引入multer库，用于处理文件上传
const multer = require('multer');
// 引入express-jwt库中的expressjwt部分，可能用于处理基于JWT的身份验证中间件相关功能
const { expressjwt } = require('express-jwt');


const app = express();
const port = 3000;

// 用于签署访问令牌(JWT)的密钥, 自行设置
const ACCESS_TOKEN_SECRET = 'YourSecret';
const TOKEN_EXPIRE = '3600s';
// 定义一个白名单数组，包含不需要进行权限验证等特定处理的路由路径
const WHITE_LIST = ['/login', '/', '/styles/', '/favicon.ico', '/fonts/', '/images/*'];

// 设置静态文件目录
app.use('/pictures', express.static(path.join(__dirname, 'vue-shopping', 'public', 'picture')));

// 允许跨域请求
app.use(cors());

app.use(bodyParser.urlencoded({ extended: true })); // 用于处理非文件的表单字段
app.use(bodyParser.json()); // 用于处理 JSON 数据

// 设置数据库连接
const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: 'root', // 请用你自己的数据库密码
  database: 'ping' // 请用你自己的数据库名称
});

// 连接数据库
// 尝试连接数据库，若连接出错，则在控制台输出错误信息并终止进程
// 若连接成功，则在控制台输出提示信息
db.connect(err => {
  if (err) {
    console.error('无法连接到数据库:', err);
    process.exit(1);
  }
  console.log('数据库连接成功');
});


//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// 设置文件存储和上传配置
// 设置商品图片文件存储的配置，指定文件保存的目的地目录以及文件名的生成规则
// 目的地是'vue-shopping/public/picture/titleimg'目录，文件名使用当前时间戳加上原始文件名的扩展名
const pictureStorage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, path.join(__dirname, 'vue-shopping', 'public', 'picture', 'titleimg'));
  },
  filename: function (req, file, cb) {
    cb(null, Date.now() + path.extname(file.originalname));
  }
});


// 设置长图文件存储的配置，与上面类似，只是保存目录为'vue-shopping/public/picture/longimg'
const longImageStorage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, path.join(__dirname, 'vue-shopping', 'public', 'picture', 'longimg'));
  },
  filename: function (req, file, cb) {
    cb(null, Date.now() + path.extname(file.originalname));
  }
});



// 创建一个基于配置好的存储方式（pictureStorage）的文件上传中间件，用于处理名为'files'的文件字段，最多允许上传10个文件
const pictureUpload = multer({ storage: pictureStorage }).array('files', 10);
// 创建一个用于长图上传的类似中间件，基于longImageStorage配置，处理长图文件上传
const longImageUpload = multer({ storage: longImageStorage }).array('files', 10);


// 商品图片上传接口，接收POST请求，使用pictureUpload中间件处理文件上传
// 如果上传成功，返回包含成功状态和图片路径信息的JSON响应；若没有上传文件，则返回相应错误信息
app.post('/upload-images', pictureUpload, (req, res) => {
  const files = req.files;
  if (!files || files.length === 0) {
    return res.status(400).json({ success: false, error: '没有上传文件' });
  }

  const imagePaths = files.map(file => path.join('picture', 'titleimg', file.filename).replace(/\\/g, '/'));
  console.log('Uploaded image paths:', imagePaths);

  res.status(200).json({ success: true, imagePaths });
});

// 长图上传接口，功能与商品图片上传接口类似，处理长图文件的上传及响应相应结果
app.post('/upload-long-image', longImageUpload, (req, res) => {
  const files = req.files;
  if (!files || files.length === 0) {
    return res.status(400).json({ success: false, error: '没有上传文件' });
  }

  const longImagePaths = files.map(file => path.join('picture', 'longimg', file.filename).replace(/\\/g, '/'));
  console.log('Uploaded long image paths:', longImagePaths);

  res.status(200).json({ success: true, longImagePaths });
});

// 提交商品信息接口，接收POST请求，同时使用商品图片和长图上传中间件处理相关文件上传
// 会对上传的商品信息进行完整性验证，然后将信息插入到相应的数据库表中，根据操作结果返回不同的JSON响应（成功或失败信息）
app.post('/submit-product', pictureUpload, longImageUpload, async (req, res) => {
  console.log('Request body:', req.body);
  console.log('Uploaded files:', req.files);

  const { productName, productPrice, detail, categoryParams, detailLines, imagePaths, longImagePaths } = req.body;

  if (!productName || !productPrice || !detail || !categoryParams || !detailLines || !imagePaths || !longImagePaths) {
    return res.status(400).json({ error: '商品信息不完整' });
  }

  try {
    const parsedCategoryParams = JSON.parse(categoryParams);
    const parsedDetailLines = JSON.parse(detailLines);

    const [productResult] = await db.promise().query(
      'INSERT INTO products (name, price, detail) VALUES (?, ?, ?)',
      [productName, productPrice, detail]
    );
    const productId = productResult.insertId;

    // 插入商品图片路径
    if (imagePaths) {
      for (const imgPath of JSON.parse(imagePaths)) {
        await db.promise().query('INSERT INTO product_images (product_id, image_path) VALUES (?, ?)', [productId, imgPath]);
      }
    }

    // 插入商品类目
    for (const category of parsedCategoryParams) {
      for (const param of category.params) {
        await db.promise().query('INSERT INTO product_categories (product_id, category_param) VALUES (?, ?)', [productId, param]);
      }
    }

    // 插入长图路径
    if (longImagePaths) {
      for (const longImg of JSON.parse(longImagePaths)) {
        await db.promise().query('INSERT INTO product_detail_images (product_id, image_path) VALUES (?, ?)', [productId, longImg]);
      }
    }

    // 插入商品详细信息行
    for (const detailLine of parsedDetailLines) {
      await db.promise().query('INSERT INTO product_category_options (product_id, option_value) VALUES (?, ?)', [productId, detailLine]);
    }

    res.status(200).json({ message: '商品信息已成功插入数据库' });
  } catch (error) {
    console.error('Error in /submit-product route:', error);
    res.status(500).json({ error: '服务器错误，请稍后再试', details: error.message });
  }
});


//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// 登录接口，接收POST请求，用于验证用户登录信息
// 首先在'pingus'表中查找用户，若不存在则在'pingsj'表中查找
// 根据查找结果判断用户是否存在以及密码是否正确，若验证通过则生成JWT Token并返回包含登录成功信息、Token及重定向路径的JSON响应
app.post('/login', (req, res) => {
  console.log('Received body:', req.body);  // 打印 body 数据
  console.log('Received files:', req.files);  // 打印文件数据

  const { user, pass } = req.body;


  // 在数据库中查找用户
  const query = 'SELECT * FROM pingus WHERE email = ?';
  db.query(query, [user], (err, results) => {
    if (err) {
      return res.status(500).json({ message: '查询数据库时出错' });
    }

    if (results.length === 0) {
      // 用户不存在，继续查找另一个表 pingsj
      const query2 = 'SELECT * FROM pingsj WHERE email = ?';
      db.query(query2, [user], (err2, results2) => {
        if (err2) {
          return res.status(500).json({ message: '查询数据库时出错' });
        }

        if (results2.length === 0) {
          return res.status(401).json({ message: '用户不存在' });
        }

        // 用户在 pingsj 表中
        const userData = results2[0];
        if (userData.password !== pass) {
          return res.status(401).json({ message: '密码错误' });
        }

        // 生成 JWT Token，并传递 nickname 信息
        const token = jwt.sign({ userId: userData.id, email: userData.email, nickname: userData.nickname, table: 'pingsj' }, ACCESS_TOKEN_SECRET, { expiresIn: TOKEN_EXPIRE });

        res.json({ message: '登录成功', token, redirect: '/xianqing' });
      });
    } else {
      // 用户在 pingus 表中
      const userData = results[0];
      if (userData.password !== pass) {
        return res.status(401).json({ message: '密码错误' });
      }

      // 生成 JWT Token，并传递 nickname 信息
      const token = jwt.sign({ userId: userData.id, email: userData.email, nickname: userData.nickname, table: 'pingus' }, ACCESS_TOKEN_SECRET, { expiresIn: TOKEN_EXPIRE });

      res.json({ message: '登录成功', token, redirect: '/' });
    }
  });
});
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////





///////////////////////////////////////////////////////////////////////////////////////////////////////

// 获取商品数据接口，接收GET请求，从数据库中查询商品相关信息（包括商品基本信息、图片路径、类目等）
// 对查询结果进行处理，将图片路径整理为合适的格式以便前端使用，最后将结果以JSON格式返回给客户端
app.get('/api/products', (req, res) => {
  const query = `
    SELECT
      p.id,
      p.name,
      p.price,
      p.detail,
      GROUP_CONCAT(CONCAT('/pictures/', pi.image_path)) AS image,
      GROUP_CONCAT(pc.category_param) AS categories
    FROM products p
    LEFT JOIN product_images pi ON p.id = pi.product_id
    LEFT JOIN product_categories pc ON p.id = pc.product_id
    GROUP BY p.id;
  `;

  db.query(query, (err, results) => {
    if (err) {
      console.error('查询失败:', err);
      return res.status(500).json({ error: '数据库查询失败' });
    }

    // 处理图片路径，确保前端可以通过正确的 URL 访问图片
    results.forEach(product => {
      if (product.image) {
        // 将 image 字符串按逗号分隔，并加上静态文件路径前缀 /pictures/
        product.imageList = product.image.split(',').map(imagePath => `/pictures${imagePath}`);
      } else {
        product.imageList = [];
      }
    });

    res.json(results);
  });
});

// 新增一个获取随机图片的接口，接收GET请求，从指定的图片目录中随机选择一定数量（此处设为8张）的图片文件
// 读取图片目录下的文件，过滤出图片文件后进行随机选择，最后将随机选择的图片文件名数组以JSON格式返回给客户端
app.get('/api/random-images', (req, res) => {
  const fs = require('fs');
  const imagesDir = path.join(__dirname, 'vue-shopping', 'public', 'picture', 'titleimg');

  // 读取图片目录下的文件
  fs.readdir(imagesDir, (err, files) => {
    if (err) {
      console.error('读取图片目录失败:', err);
      return res.status(500).json({ error: '读取图片失败' });
    }

    // 过滤出图片文件（假设都是图片文件）
    const imageFiles = files.filter(file => /\.(jpg|jpeg|png|gif)$/.test(file));

    // 随机选择几张图片
    const randomImages = [];
    const numberOfImages = 8;  // 假设你想要随机展示 8 张图片
    for (let i = 0; i < numberOfImages; i++) {
      const randomIndex = Math.floor(Math.random() * imageFiles.length);
      randomImages.push(imageFiles[randomIndex]);
    }

    // 返回图片路径数组
    res.json(randomImages);
  });
});

// 处理搜索请求的接口，接收GET请求，根据客户端提供的搜索关键词在数据库中模糊匹配商品名称
// 如果没有提供关键词则返回相应错误信息，查询成功则将匹配到的商品名称数组以JSON格式返回给客户端
app.get('/search', (req, res) => {
  const keyword = req.query.keyword;

  if (!keyword) {
    return res.status(400).send('没有提供搜索关键词');
  }

  // 查询数据库，模糊匹配商品名称
  const query = 'SELECT name FROM products WHERE name LIKE ? LIMIT 10';
  db.query(query, [`%${keyword}%`], (err, results) => {
    if (err) {
      console.error('查询数据库时出错:', err);
      return res.status(500).send('数据库查询失败');
    }

    // 返回查询结果
    const productNames = results.map(result => result.name);
    res.json(productNames);
  });
});

// 用户注册接口，接收POST请求，将客户端提交的用户注册信息（邮箱、昵称、密码）插入到'pingus'表中
// 根据插入操作结果返回相应的JSON响应（成功或失败信息）
app.post('/api/register/user', (req, res) => {
  const { email, nickname, password } = req.body;
  const sql = 'INSERT INTO pingus (email, nickname, password) VALUES (?, ?, ?)';

  db.query(sql, [email, nickname, password], (error, results) => {
    if (error) {
      return res.status(500).json({ message: '注册失败', error });
    }
    res.status(200).json({ message: '注册成功' });
  });
});

// 商家注册接口，功能与用户注册接口类似，将商家注册信息插入到'pingsj'表中，并返回相应的注册结果响应
app.post('/api/register/admin', (req, res) => {
  const { email, nickname, password } = req.body;
  const sql = 'INSERT INTO pingsj (email, nickname, password) VALUES (?, ?, ?)';

  db.query(sql, [email, nickname, password], (error, results) => {
    if (error) {
      return res.status(500).json({ message: '注册失败', error });
    }
    res.status(200).json({ message: '注册成功' });
  });
});

// 启动服务器，使其监听在指定的端口（3000）上，当服务器成功启动后在控制台输出相应提示信息
app.listen(port, () => {
  console.log(`服务器正在监听 http://localhost:${port}`);
});
