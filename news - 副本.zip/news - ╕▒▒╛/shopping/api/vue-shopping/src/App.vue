<script setup>
import { RouterLink, RouterView } from 'vue-router'
</script>

<template>
  <header>
    <div class="wrapper">
      <nav>
        <!-- 使用 RouterLink 组件创建一个导航链接，指向应用的根路径（'/'），显示的文本为 'Home' -->
        <!-- 当用户点击这个链接时，会触发路由跳转，跳转到对应的路由路径，然后由 RouterView 渲染相应的组件内容 -->
        <RouterLink to="/">Home </RouterLink>
        <RouterLink to="/enter">enter </RouterLink>
        <RouterLink to="/zhuce">zhuce </RouterLink>
        <RouterLink to="/xianqing">xianqing </RouterLink>
        <RouterLink to="/tianjia">tianjia  </RouterLink>
        <RouterLink to="/gouwuche">gouwuche</RouterLink>
      </nav>
    </div>
  </header>

  <RouterView />
</template>

<style scoped>

</style>