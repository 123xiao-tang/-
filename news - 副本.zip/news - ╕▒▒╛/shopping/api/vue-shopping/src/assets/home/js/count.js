//购物车总数计算//
$(document).ready(function() {
    // 从 localStorage 中获取 count 值
    var count = localStorage.getItem('cartItemCount');

    // 如果 count 存在，则更新购物车中的 count 元素
    if (count !== null) {
        $(".count em").text(count);
    }
});

