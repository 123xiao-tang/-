// 从 'vue-router' 库中导入 createRouter 和 createWebHistory 函数
// createRouter 用于创建 Vue 应用的路由实例
// createWebHistory 用于创建基于浏览器历史记录模式的路由历史对象，以支持浏览器的前进、后退等导航操作
import { createRouter, createWebHistory } from 'vue-router'
// 导入各个页面视图对应的 Vue 组件，这些组件定义了不同页面的具体内容和结构
import HomeView from '@/views/HomeView.vue'
import EnterView from '@/views/EnterView.vue'
import ZhuceView from '@/views/ZhuceView.vue'
import SpXianqing from '@/views/SpXianqing.vue'
import TianJia from '@/views/TianjiaShangping.vue'
import GouwuChe from '@/views/GouwuChe.vue'

const router = createRouter({
  // 配置路由的历史记录模式
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      // 路由的路径，'/' 表示应用的根路径，当用户访问应用的根 URL 时，会匹配到这个路由
      path: '/',
      // 给这个路由定义一个名称，方便在代码中通过名称来引用该路由，例如在编程式导航时使用
      name: 'home',
      // 指定与该路由对应的 Vue 组件，当访问此路由路径时，将会渲染这个组件，展示对应的页面内容
      component: HomeView,
    },
    {
      path: '/enter',
      name: 'enter',
      component: EnterView
    },
    {
      path: '/zhuce',
      name: 'zhuce',
      component: ZhuceView
    },
    {
      path: '/xianqing',
      name: 'xianqing',
      component: SpXianqing
    },
    {
      path: '/tianjia',
      name: 'tianjia',
      component: TianJia
    },
    {
      path: '/gouwuche',
      name: 'gouwuche',
      component: GouwuChe
    },
  ],
})

// 将创建好的路由实例作为默认导出，以便在其他模块（如 Vue 应用的入口文件等）中导入并使用该路由配置
export default router
