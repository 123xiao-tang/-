<template>
  <div class="login-box">
    <div class="py-container logoArea">
      <a href="/pingyougou//主页/index.html" class="logo">返回主页</a>
    </div>
    <div class="loginArea" id="app">
      <div class="py-container login">
        <div class="loginform">
          <ul class="sui-nav nav-tabs tab-wraped">
            <li><a href="#index" data-toggle="tab">扫描登录</a></li>
            <li class="active"><a href="#profile" data-toggle="tab">账户登录</a></li>
          </ul>
          <div class="tab-content tab-wraped">
            <div id="index" class="tab-pane">
              <p>啦啦啦</p>
            </div>
            <div id="profile" class="tab-pane active">
              <form class="sui-form" @submit.prevent="login">
                <div class="container m-3">
                  <div class="input-prepend">
                    <span class="add-on loginname"></span>
                    <input type="text" class="span2 input-xfat" id="user" v-model="user" placeholder="用户名/邮箱">
                  </div>
                  <div class="input-prepend">
                    <span class="add-on loginpwd"></span>
                    <input type="password" class="span2 input-xfat" id="pass" v-model="pass" placeholder="请输入密码">
                  </div>
                  <div>{{ serverResponse }}</div>
                </div>
                <div class="setting">
                  <label class="checkbox inline"><input name="m1" type="checkbox" checked>自动登录</label>
                  <span class="forget">忘记密码？</span>
                </div>
                <div class="logined">
                  <button type="submit" class="sui-btn btn-block btn-xlarge btn-danger">登 录</button>
                </div>
              </form>
              <div id="messageBox" class="message-box" style="display: none;"></div>
              <div class="registration">
                <a @click="checkZhuce">立即注册</a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import '@/assets/enter/css/base.css';
import '@/assets/enter/css/register.css';
// 导入 axios 库，用于发送 HTTP 请求与服务器进行交互，比如发送登录请求等
import axios from 'axios';
import { mapState } from 'vuex';

export default {
  name: 'EnterView',
  data() {
    return {
      user: '', // 用户名
      pass: '', // 密码
      serverResponse: '', // 服务端的回应数据
    };
  },
  methods: {
    async login() {
      try {
        // 使用 axios 发送 POST 请求到服务器的登录接口（假设服务器运行在本地 3000 端口的 '/login' 路径）
        // 请求体中携带了用户输入的用户名和密码信息
        const response = await axios.post('http://localhost:3000/login', { user: this.user, pass: this.pass });
        // 将服务器返回的消息赋值给 serverResponse，用于在页面上显示给用户
        this.serverResponse = response.data.message; // 显示成功消息

        // 将服务器返回的认证 token 存储到本地存储（localStorage）中，方便后续验证用户身份等操作使用
        localStorage.setItem('authToken', response.data.token);
        
        // 获取服务器返回的重定向路径，用于进行页面跳转，通过 Vue Router 进行路由导航，跳转到相应页面
        const redirectPath = response.data.redirect;
        this.$router.push(redirectPath);
      } catch (error) {
        // 如果请求有响应（error.response 存在），说明服务器返回了错误信息，进一步根据状态码等处理错误提示
        if (error.response) {
          if (error.response.status === 401) {
            this.serverResponse = '无效的用户名或密码';
          } else {
            this.serverResponse = error.response.data.message || '登录失败';
          }
        } else {
          this.serverResponse = '网络错误';
        }
      }
    }
  }
};
</script>
