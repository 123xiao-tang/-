<template>
    <div>
      <!-- 顶部快捷导航start -->
      <div class="shortcut">
        <div class="w">
          <div class="fl">
            <ul>
              <li>品优购欢迎您！</li>
              <li>
                <a href="#">请登录</a>
                <a href="#" class="style-red">免费注册</a>
              </li>
            </ul>
          </div>
          <div class="fr">
            <ul>
              <li><a href="#">我的订单</a></li>
              <li class="spacer"></li>
              <li><a href="#">我的品优购</a> <i class="icomoon"></i></li>
              <li class="spacer"></li>
              <li><a href="#">品优购会员</a></li>
              <li class="spacer"></li>
              <li><a href="#">企业采购</a></li>
              <li class="spacer"></li>
              <li><a href="#">关注品优购</a> <i class="icomoon"></i></li>
              <li class="spacer"></li>
              <li><a href="#">客户服务</a> <i class="icomoon"></i></li>
              <li class="spacer"></li>
              <li><a href="#">网站导航</a> <i class="icomoon"></i></li>
            </ul>
          </div>
        </div>
      </div>
      <!-- 顶部快捷导航end -->
  
      <div class="car-header">
        <div class="w">
          <div class="car-logo">
            <img src="" alt=""> <b>购物车</b>
          </div>
        </div>
      </div>
  
      <div class="c-container">
        <div class="w">
          <div class="cart-filter-bar">
            <em>全部商品</em>
          </div>
  
          <!-- 购物车主要核心区域 -->
          <div class="cart-warp">
            <!-- 头部全选模块 -->
            <div class="cart-thead">
              <div class="t-checkbox">
                <input type="checkbox" v-model="selectAll" @change="toggleSelectAll"> 全选
              </div>
              <div class="t-goods">商品</div>
              <div class="t-price">单价</div>
              <div class="t-num">数量</div>
              <div class="t-sum">小计</div>
              <div class="t-action">操作</div>
            </div>
  
            <!-- 商品详细模块，通过 v-for 指令循环展示购物车中的每个商品信息及操作按钮等 -->
            <div class="cart-item-list">
              <div v-for="(item, index) in cartItems" :key="index" class="cart-item">
                <div class="p-checkbox">
                  <input type="checkbox" v-model="item.selected" @change="updateSelectAll">
                </div>
                <div class="p-goods">
                  <div class="p-img">
                    <img :src="item.imgSrc" alt="">
                  </div>
                  <div class="p-msg">{{ item.name }}</div>
                </div>
                <div class="p-price">￥{{ item.price }}</div>
                <div class="p-num">
                  <div class="quantity-form">
                    <button @click="decrementQuantity(index)">-</button>
                    <input type="text" class="itxt" v-model.number="item.quantity">
                    <button @click="incrementQuantity(index)">+</button>
                  </div>
                </div>
                <div class="p-sum">￥{{ item.price * item.quantity }}</div>
                <div class="p-action"><button @click="removeItem(index)">删除</button></div>
              </div>
            </div>
  
            <!-- 结算模块 -->
            <div class="cart-floatbar">
              <div class="select-all">
                <input type="checkbox" v-model="selectAll" @change="toggleSelectAll">全选
              </div>
              <div class="operation">
                <button @click="removeSelectedItems">删除选中的商品</button>
                <button @click="clearCart">清理购物车</button>
              </div>
              <div class="toolbar-right">
                <div class="amount-sum">已经选{{ selectedItems.length }}件商品</div>
                <div class="price-sum">总价： <em>￥{{ totalPrice }}</em></div>
                <div class="btn-area">
                  <button @click="goToCheckout">去结算</button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
  
      <!-- 页面底部开始部分，用于展示一些服务相关信息 -->
      <div class="footer">
        <div class="w">
          <!-- 服务模块，通过 v-for 循环展示不同的服务项目，每个项目包含图标、标题和描述 -->
          <div class="mod_service">
            <ul>
              <li v-for="(service, index) in services" :key="index">
                <i :class="service.iconClass"></i>
                <div class="mod_service_tit">
                  <h5>{{ service.title }}</h5>
                  <p>{{ service.description }}</p>
                </div>
              </li>
            </ul>
          </div>
        </div>
      </div>
      <!-- 页面底部结束 -->
    </div>
  </template>
  
  <script>
import '@/assets/gouwuche/css/base.css';
import '@/assets/gouwuche/css/car.css';
import '@/assets/gouwuche/css/common.css';


  export default {
    data() {
      return {
        cartItems: [
          {
            imgSrc: "upload/p1.jpg",
            name: "【5本26.8元】经典儿童文学彩图青少版八十天环游地球中学生语文教学大纲",
            price: 12.60,
            quantity: 1,
            selected: true
          },
          {
            imgSrc: "upload/p2.jpg",
            name: "【2000张贴纸】贴纸书 3-6岁 贴画儿童 贴画书全套12册 贴画 贴纸儿童 汽",
            price: 24.80,
            quantity: 1,
            selected: true
          },
          {
            imgSrc: "upload/p3.jpg",
            name: "唐诗三百首+成语故事全2册 一年级课外书 精装注音儿童版 小学生二三年级课外阅读书籍",
            price: 29.80,
            quantity: 1,
            selected: true
          }
        ],
        selectAll: true,
        services: [
          { iconClass: "mod-service-icon mod_service_zheng", title: "正品保障", description: "正品保障，提供发票" },
          { iconClass: "mod-service-icon mod_service_kuai", title: "快速配送", description: "3小时内送达" },
          { iconClass: "mod-service-icon mod_service_bao", title: "售后服务", description: "7天无理由退换" },
          { iconClass: "mod-service-icon mod_service_bao", title: "付款方式", description: "支持多种支付方式" },
          { iconClass: "mod-service-icon mod_service_bao", title: "订单查询", description: "24小时查询订单状态" }
        ]
      };
    },
    computed: {
      // 计算属性，通过筛选购物车商品数组，返回被选中的商品组成的新数组
      selectedItems() {
        return this.cartItems.filter(item => item.selected);
      },
      // 计算属性，计算被选中商品的总价，通过遍历被选中商品数组，累加每个商品的价格乘以数量的结果，并保留两位小数
      totalPrice() {
        return this.selectedItems.reduce((sum, item) => sum + item.price * item.quantity, 0).toFixed(2);
      }
    },
    methods: {
      // 全选复选框状态改变时触发的方法，用于更新所有商品的选中状态与全选复选框状态保持一致
      toggleSelectAll() {
        this.cartItems.forEach(item => {
          item.selected = this.selectAll;
        });
      },
      // 单个商品复选框状态改变时触发的方法，用于更新全选复选框状态，根据所有商品是否都被选中来决定全选框的勾选情况
      updateSelectAll() {
        this.selectAll = this.cartItems.every(item => item.selected);
      },
      // 减少商品数量的方法，点击商品数量减号按钮时触发，当数量大于1时才允许减少
      decrementQuantity(index) {
        if (this.cartItems[index].quantity > 1) {
          this.cartItems[index].quantity--;
        }
      },
      // 增加商品数量的方法，点击商品数量加号按钮时触发，每次点击数量加1
      incrementQuantity(index) {
        this.cartItems[index].quantity++;
      },
      // 删除单个商品的方法，根据传入的商品索引，从购物车商品数组中移除该商品
      removeItem(index) {
        this.cartItems.splice(index, 1);
      },
      // 删除所有被选中商品的方法，通过过滤购物车商品数组，只保留未被选中的商品，实现删除选中商品的功能
      removeSelectedItems() {
        this.cartItems = this.cartItems.filter(item => !item.selected);
      },
      // 清空购物车的方法，将购物车商品数组置为空数组，实现清理购物车的功能
      clearCart() {
        this.cartItems = [];
      },
      goToCheckout() {
        // 去结算的方法，目前只是简单弹出一个提示框，实际应用中可在这里实现跳转到结算页面或者相关结算逻辑
        alert("去结算");
      }
    }
  };
  </script>
  
  <style scoped>

  </style> 