<template>
  <!-- 顶部快捷导航start -->
  <div class="shortcut">
    <div class="w">
      <div class="fl">
        <ul>
          <li>品优购欢迎您! <a class="style-red">{{ username }}</a> !</li>
          <li>
            <!-- 阻止默认跳转并绑定点击事件函数 -->
            <a href="javascript:void(0);" @click="checkRegistration">请登录</a>
            <a class="style-red" @click="checkZhuce">免费注册</a>
          </li>
        </ul>
      </div>
      <div class="fr">
        <ul>
          <li><a href="#">我的订单</a></li>
          <li class="spacer"></li>
          <li>
            <a href="#">我的品优购</a>
            <i class="icomoon"></i>
          </li>
          <li class="spacer"></li>
          <li><a href="../其他页面/品优购会员.html">品优购会员</a></li>
          <li class="spacer"></li>
          <li><a href="#">企业采购</a></li>
          <li class="spacer"></li>
          <li><a href="../其他页面/关注品优购.html">关注品优购</a> <i class="icomoon"></i></li>
          <li class="spacer"></li>
          <li><a href="../其他页面/客户服务.html">客户服务</a> <i class="icomoon"></i></li>
          <li class="spacer"></li>
          <li><a href="index.html">网站导航</a> <i class="icomoon"></i></li>
        </ul>
      </div>
    </div>
  </div>
  <!-- 顶部快捷导航end  -->
  <!-- header制作 -->
  <div class="header w">
    <!-- logo -->
    <div class="logo">
      <h1>
        <a href="index.html" title="品优购">品优购</a>
      </h1>
    </div>
    <!-- search -->
    <div class="search">
      <input type="text" v-model="keyword" class="keyword" placeholder="请搜索内容..." @input="onSearchInput" @blur="onBlur"
        ref="keywordInput" />
      <button class="btn" @click="onSearchClick">搜索</button>

      <!-- 搜索提示框 -->
       <!-- searchHelperVisible为真，就会添加'visible'类名 -->
      <div class="search-helper" v-if="searchHelperVisible" :class="{'visible': searchHelperVisible}">
        <p v-for="(item, index) in filteredSearchResults" :key="index">{{ item }}</p>
      </div>
    </div>
    <div class="shopcar">
      <i class="car"></i><a href="../购物车/index.html">我的购物车</a> <i class="arrow">  </i>
      <i class="count"><em>{{ cartItemCount }}</em></i>
    </div>
  </div>

  <!-- header 结束 -->
  <!-- nav start -->
  <div class="nav">
    <div class="w">
      <div class="dropdown fl">
        <div class="dt"> 全部商品分类 </div>
        <div class="dd">
          <ul>
            <li class="menu_item"><a href="../侧边文件/家用电器/list.html">家用电器</a> <i>  </i> </li>
            <li class="menu_item">
              <a href="../侧边文件/手机、数码、通信/list.html">手机、数码、通信</a>
              <i>  </i>
            </li>
            <li class="menu_item"><a href="../侧边文件/电脑、办公/list.html">电脑、办公</a> <i>  </i> </li>
            <li class="menu_item"><a href="../侧边文件/家居、家具、家装、厨具/list.html">家居、家具、家装、厨具</a> <i>  </i> </li>
            <li class="menu_item"><a href="../侧边文件/男装、女装、童装、内衣/list.html">男装、女装、童装、内衣</a> <i>  </i> </li>
          </ul>
        </div>
      </div>
      <!-- 右侧导航 -->
      <div class="navitems fl">
        <ul>
          <li><a href="#">服装城</a></li>
          <li><a href="#">美妆馆</a></li>
          <li><a href="#">传智超市</a></li>
          <li><a href="#">全球购</a></li>
          <li><a href="#">闪购</a></li>
          <li><a href="#">团购</a></li>
          <li><a href="#">拍卖</a></li>
          <li><a href="#">有趣</a></li>
        </ul>
      </div>
    </div>
  </div>
  <!-- nav end  -->
  <!-- main 模块 -->
  <div class="w">
    <div class="main">
      <div class="focus fl">
        <!-- 左侧按钮 -->
        <a href="javascript:;" class="arrow-l">
          &lt;
        </a>
        <!-- 右侧按钮 -->
        <a href="javascript:;" class="arrow-r">  </a>
        <!-- 核心的滚动区域 -->
        <ul>
          <li>
            <a href="#"><img data-lazy-src="upload/focus.jpg" alt=""></a>
          </li>
          <li>
            <a href="#"><img data-lazy-src="upload/focus1.jpg" alt=""></a>
          </li>
          <li>
            <a href="#"><img data-lazy-src="upload/focus2.jpg" alt=""></a>
          </li>
          <li>
            <a href="#"><img data-lazy-src="upload/focus3.jpg" alt=""></a>
          </li>
        </ul>
        <!-- 小圆圈 -->
        <ol class="circle">

        </ol>
      </div>
      <div class="newsflash fr">
        <div class="news">
          <div class="news-hd">
            品优购快报
            <a href="#">更多</a>
          </div>
          <div class="news-bd">
            <ul>
              <li><a href="#">【特惠】爆款耳机5折秒！</a></li>
              <li><a href="#">【特惠】母亲节，健康好礼低至5折！</a></li>
              <li><a href="#">【特惠】爆款耳机5折秒！</a></li>
              <li><a href="#">【特惠】9.9元洗100张照片！</a></li>
              <li><a href="#">【特惠】长虹智能空调立省1000</a></li>
            </ul>
          </div>
        </div>
        <div class="lifeservice">
          <ul>
            <li>
              <a href="#">
                <i class="service_ico service_ico_huafei"></i>
                <p>话费</p>
              </a>
            </li>
            <li>
              <a href="#">
                <i class="service_ico service_ico_feiji"></i>
                <p>机票</p>
              </a>
              <span class="hot"></span>
            </li>
            <li>
              <a href="#">
                <i class="service_ico service_ico_feiji"></i>
                <p>火车票</p>
              </a>
            </li>
            <li>
              <a href="#">
                <i class="service_ico service_ico_feiji"></i>
                <p>充值</p>
              </a>
            </li>
            <li>
              <a href="#">
                <i class="service_ico service_ico_feiji"></i>
                <p>批发</p>
              </a>
            </li>
            <li>
              <a href="#">
                <i class="service_ico service_ico_feiji"></i>
                <p>免税</p>
              </a>
            </li>
            <li>
              <a href="#">
                <i class="service_ico service_ico_feiji"></i>
                <p>办公</p>
              </a>
            </li>
            <li>
              <a href="#">
                <i class="service_ico service_ico_feiji"></i>
                <p>AI</p>
              </a>
            </li>
            <li>
              <a href="#">
                <i class="service_ico service_ico_feiji"></i>
                <p>进口</p>
              </a>
            </li>
            <li>
              <a href="#">
                <i class="service_ico service_ico_feiji"></i>
                <p>时事</p>
              </a>
            </li>
            <li>
              <a href="#">
                <i class="service_ico service_ico_feiji"></i>
                <p>天猫</p>
              </a>
            </li>
            <li>
              <a href="#">
                <i class="service_ico service_ico_feiji"></i>
                <p>京喜</p>
              </a>
            </li>
          </ul>
        </div>
        <div class="bargain">
          <img data-lazy-src="upload/bargain.jpg" alt="">
        </div>
      </div>
    </div>
  </div>

  <!-- 楼层区 start -->
  <div class="floor">
    <div class="jiadian w">
      <div class="box-hd">
        <h3>今日推荐</h3>
      </div>
      <div class="box-bd">
        <div class="tab-con">
          <div v-for="(image, index) in images" :key="index" class="w220">
            <div class="tab-con-item">
              <a href="#">
                <img :src="'http://localhost:3000/pictures/' + image" alt="商品图片">
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- 楼层区 end -->
  <!-- 固定电梯导航 -->
  <div class="fixedtool">
    <ul>
      <li class="current">家用电器</li>
      <li>手机通讯</li>
      <li>电脑办公</li>
      <li>精品家具</li>

    </ul>
  </div>
  <!-- footer start -->
  <div class="footer">
    <div class="w">
      <!-- mod_copyright  -->
      <div class="mod_copyright">
        <p class="mod_copyright_links">
          关于我们 | 联系我们 | 联系客服 | 商家入驻 | 营销中心 | 手机品优购 | 友情链接 | 销售联盟 | 品优购社区 | 品优购公益 | English Site | Contact U
        </p>
        <p class="mod_copyright_info">
          地址：北京市昌平区建材城西路金燕龙办公楼一层 邮编：114514 电话：15159791232 传真：010-82935100 邮箱: 1801333677@qq.com <br>
          京ICP备08001421号京公网安备110108007702
        </p>
      </div>
    </div>
  </div>
</template>
<script>
import '../assets/home/css/base.css';
import '../assets/home/css/common.css';
import '../assets/home/css/index.css';
// 导入axios库，用于发送HTTP请求与服务器进行交互，比如获取数据、查询搜索结果等操作
import axios from 'axios';

export default {
  name: 'HomeView',
  data() {
    return {
      images: [],  // 这里存放请求到的图片数据
      keyword: '',               // 用户输入的搜索关键词
      searchHelperVisible: false, // 是否显示搜索提示
      filteredSearchResults: [],   // 显示的搜索结果
      username: ''
    };
  },
  // Vue组件的生命周期钩子函数，在组件实例被创建后立即调用，这里主要执行两个操作
  created() {
    // 调用fetchRandomImages方法，发送请求去获取随机图片列表，用于在页面上展示相关图片内容
    this.fetchRandomImages();
    // 从本地存储（localStorage）中获取名为 'authToken' 的认证token
    const token = localStorage.getItem('authToken');
    if (token) {
      const decodedToken = JSON.parse(atob(token.split('.')[1]));
      this.username = decodedToken.nickname; // 假设你在 JWT 中存储了 email 字段
    }
  },
  methods: {
    // 方法用于处理跳转到注册相关页面的逻辑，通过Vue Router将页面导航到名为 'enter' 的路由对应的页面
    checkRegistration() {
      this.$router.push({ name: 'enter' }); // 改为 'enter'，与路由配置中的名称一致
    },
    checkZhuce() {
      this.$router.push({ name: 'zhuce' });
    },
    fetchRandomImages() {
      // 发请求去获取随机图片列表
      fetch('http://localhost:3000/api/random-images')
        .then(response => response.json())
        .then(data => {
          this.images = data;  // 将返回的图片列表保存在 data 里
        })
        .catch(err => {
          console.error('获取图片失败', err);
        });
    },
    // ////////////////////////////////////////////////////////////////////////////////////////////

    // 当输入框内容变化时触发
    onSearchInput() {
  this.searchHelperVisible = this.keyword.trim() !== '';
  
  if (this.keyword.trim() !== '') {
    this.fetchSearchResults();
  }

  // 判断是否应该更改输入框的颜色
  if (this.keyword.trim() !== '') {
    this.$refs.keywordInput.classList.add('changed');
  } else {
    this.$refs.keywordInput.classList.remove('changed');
  }
}
,
    // 当点击搜索按钮时触发
    onSearchClick() {
      // 点击搜索按钮后，隐藏搜索提示框
      this.searchHelperVisible = false; // 搜索完成后隐藏提示框
      this.fetchSearchResults();
    },
    // 向服务器发送请求查询搜索结果的方法，向 'http://localhost:3000/search' 接口发送GET请求，并携带用户输入的关键词作为参数
    fetchSearchResults() {
      axios.get('http://localhost:3000/search', { params: { keyword: this.keyword } })
        .then(response => {
          this.filteredSearchResults = response.data;
        })
        .catch(error => {
          console.error('Error fetching search results:', error);
        });
    },
    // 当搜索框失去焦点时触发的方法，通过设置一个短暂的定时器，延迟一小段时间后隐藏搜索提示框
    onBlur() {
      setTimeout(() => {
        this.searchHelperVisible = false;
      }, 200);
    }
  }

};
</script>

<style scoped>
/* 添加一些样式使得图片显示得更好看 */
.w220 {
  width: 220px;
  margin: 10px;
  display: inline-block;
}

.tab-con-item img {
  width: 100%;
  height: auto;
  display: block;
}

/* 你可以在这里添加样式 */
.search-helper {
  position: absolute;
  border: 1px solid #ccc;
  background-color: #fff;
  max-height: 200px;
  overflow-y: auto;
  width: 100%;
}

.search-helper p {
  margin: 0;
  padding: 10px;
}
</style>
