<template>
    <div class="product-page">
      <h1>商品展示</h1>
      <div class="product-list">
        <div class="product-item" v-for="product in products" :key="product.id">
          <!-- 只展示第一张图片 -->
          <div v-if="product.imageList && product.imageList.length > 0">
            <img :src="getImageUrl(product.imageList[0])" :alt="product.name" class="product-image" />
          </div>
          <div class="product-details">
            <h3>{{ product.name }}</h3>
            <p class="price">￥{{ formatPrice(product.price) }}</p>
            <p class="categories">类别: {{ product.categories }}</p>
            <p class="detail">{{ product.detail }}</p>
          </div>
        </div>
      </div>
    </div>
  </template>
  
  <script>
  // 导入axios库，用于发送HTTP请求，以便与服务器进行数据交互，在这里主要用于获取商品相关的数据
  import axios from 'axios';
  
  export default {
    name: 'ProductPage',
    data() {
      return {
        products: []
      };
    },
    // Vue组件的生命周期钩子函数'mounted'，在组件挂载到DOM后被调用，通常用于执行一些需要DOM元素存在才能进行的操作，比如获取数据并渲染到页面等，此处用于获取商品数据
    mounted() {
      // 获取商品数据
      axios.get('http://localhost:3000/api/products')
        .then(response => {
          // 处理每个商品的图片路径
          this.products = response.data.map(product => {
            // 对服务器返回的每个商品数据（response.data是包含多个商品信息的数组）进行处理，主要是处理商品的图片路径相关操作
            product.imageList = product.image ? product.image.split(',').map(imagePath => {
              // 拼接完整的图片路径，确保能够正确加载
              if (imagePath.startsWith('/pictures')) {
                return `http://localhost:3000${imagePath}`;  // 从服务器访问图片路径
              }
              return imagePath; // 如果路径已经是完整的，就不再加前缀
            }) : [];
            return product;
          });
        })
        .catch(error => {
          console.error("获取商品数据失败:", error);
        });
    },
    methods: {
      // 方法用于获取完整的图片路径，当前只是简单返回传入的图片路径
      getImageUrl(imagePath) {
        return imagePath; // 使用映射后的完整路径
      },
      /// 格式化价格的方法，将传入的价格参数转换为数字类型（如果可以转换的话），然后使用'toFixed(2)'方法将其保留两位小数后返回，以符合常见的价格显示格式要求
            // 如果传入的参数无法转换为数字（比如是字符串且不符合数字格式等情况），则直接返回原值
      formatPrice(price) {
        const numericPrice = Number(price);
        if (!isNaN(numericPrice)) {
          return numericPrice.toFixed(2); 
        }
        return price; 
      }
    }
  };
  </script>
  
  <style scoped>
  .product-page {
    font-family: Arial, sans-serif;
    padding: 20px;
  }
  
  .product-list {
    display: flex;
    flex-wrap: wrap;
    gap: 20px;
  }
  
  .product-item {
    width: 23%;
    border: 1px solid #ddd;
    padding: 10px;
    border-radius: 8px;
    text-align: center;
  }
  
  .product-image {
    width: 100%;
    height: auto;
    border-radius: 8px;
  }
  
  .product-details {
    margin-top: 10px;
  }
  
  h3 {
    font-size: 18px;
    color: #333;
  }
  
  .price {
    font-size: 16px;
    color: #e74c3c;
    font-weight: bold;
  }
  
  .categories {
    font-size: 14px;
    color: #555;
  }
  
  .detail {
    font-size: 14px;
    color: #777;
    margin-top: 10px;
  }
  </style>
  