<template>
  <div>
    <!-- 商品图片部分 -->
    <div class="de_container w">
      <div class="hea">
        <span>商品图片</span>
        <button @click="triggerFileInput">添加商品图片</button>
        <input type="file" ref="fileInput" accept="image/*" multiple style="display: none;"
          @change="handleFileChange" />
      </div>
      <div class="picture" id="picture-container">
        <div class="thumbnail" v-for="(image, index) in images" :key="index" @click="changeImage(image)">
          <img :src="image" :alt="'Image ' + (index + 1)" />
        </div>
      </div>
    </div>

    <!-- 类目属性部分 -->
    <div class="de_container w">
      <div class="hea">
        <span>类目属性</span>
        <button @click="addCategory">添加商品类目</button>
      </div>
      <div class="gategory" id="gategoryContainer">
        <div class="gategory-aaa">
          <p class="fixed">商品名字</p>
          <input class="first" type="text" v-model="productName" placeholder="请输入商品名字" />
          <p class="fixed">商品价格</p>
          <input class="first" type="text" v-model="productPrice" placeholder="请输入商品价格" />
        </div>
        <div v-for="(category, index) in categories" :key="index" class="gategory-item">
          <input v-model="category.name" class="first" type="text" placeholder="请输入商品类目" />

          <!-- 动态生成的datalist -->
          <input v-model="category.selectedParam" class="parameters" list="paramList" placeholder="请选择或输入类目参数" />

          <!-- datalist -->
          <datalist id="paramList">
            <option v-for="(param, i) in category.params" :key="i" :value="param">{{ param }}</option>
          </datalist>



          <button @click="addParam(index)" class="addParamButton">添加</button>
          <button @click="removeParam(index)" class="removeButton">删除</button>
        </div>
      </div>
    </div>

    <!-- 详细介绍部分 -->
    <div class="de_container w">
      <div class="hea">
        <span>详细介绍</span>
        <button @click="triggerLongImageInput">添加详细长图</button>
        <input type="file" ref="fileInputLong" accept="image/*" multiple style="display: none;"
          @change="handleLongImageChange" />
      </div>
      <div class="detalied">
        <div class="script">
          <textarea v-model="detail" placeholder="请输入商品详细参数"></textarea>
        </div>
        <div class="image-container" id="imageContainer">
          <img v-for="(image, index) in detailImages" :src="image" :alt="'Detail Image ' + (index + 1)" />
        </div>
      </div>
    </div>

    <!-- 提交按钮部分 -->
    <div class="de_container w">
      <div class="upload">
        <button @click="submitProduct">提交</button>
        <button @click="cancelProduct">取消</button>
      </div>
    </div>
  </div>
</template>

<script>
import '@/assets/Tianjia/css/detail.css';
// 导入axios库，用于发送HTTP请求与服务器进行交互，比如上传文件、提交商品信息等操作
import axios from 'axios';

export default {
  data() {
    return {
      productName: '',
      productPrice: '',
      categories: [],
      categoryParams: ['参数1', '参数2', '参数3'], // 默认的类目参数
      images: [], // 用于保存 DataURL
      imageFiles: [], // 用于保存文件对象
      detailImages: [], // 用于保存长图的 DataURL
      longImageFiles: [], // 用于保存长图的文件对象
      detail: '',
    };
  },
  methods: {
    // 方法用于触发文件输入框的点击事件，通过访问组件中绑定了'refs'的文件输入框元素（假设存在名为'fileInput'的文件输入框引用），模拟用户点击操作，以便用户选择文件
    triggerFileInput() {
      this.$refs.fileInput.click();
    },
    handleFileChange(event) {
      const files = Array.from(event.target.files);
      files.forEach(file => {
        const reader = new FileReader();
        reader.onload = (e) => {
          this.images.push(e.target.result); // 保存 DataURL 用于前端显示
        };
        reader.readAsDataURL(file); // 读取文件为 DataURL
      });
      this.imageFiles.push(...files); // 存储文件对象，用于上传
    },
    // 方法用于修改图片相关逻辑，当前代码中未具体实现修改图片的详细功能，可能后续需要根据具体需求补充，比如替换图片、编辑图片等操作
    changeImage(image) {
      // 修改图片的逻辑
    },
    // 方法用于添加新的商品类目，向'categories'数组中添加一个新的类目对象，该对象包含类目名称、默认选中的参数（初始为空）以及一组类目参数（复制了默认的类目参数列表）
    addCategory() {
      // 添加新的类目，并初始化类目参数
      this.categories.push({
        name: '',
        selectedParam: '', // 默认选中为空
        params: [...this.categoryParams], // 复制默认的类目参数
      });
    },
    // 方法用于在指定的类目下添加新的类目参数，根据传入的类目索引（categoryIndex）来操作对应的类目对象
    addParam(categoryIndex) {
      const category = this.categories[categoryIndex];
      const newParam = category.selectedParam.trim();

      // 检查是否已存在
      if (newParam) {
        if (category.params.includes(newParam)) {
          alert('您已有相同参数！');
        } else {
          category.params.push(newParam);
          category.selectedParam = ''; // 清空输入框
        }
      } else {
        alert('请输入类目参数！');
      }
    },
    // 方法用于在指定的类目下删除类目参数，同样依据传入的类目索引来操作对应类目对象
    removeParam(categoryIndex) {
      const category = this.categories[categoryIndex];
      const paramToRemove = category.selectedParam.trim();

      if (paramToRemove) {
        const paramIndex = category.params.indexOf(paramToRemove);
        if (paramIndex !== -1) {
          category.params.splice(paramIndex, 1);
          alert('参数已删除！');
          category.selectedParam = ''; // 清空输入框
        } else {
          alert('您没有这个参数，无法删除!');
        }
      } else {
        alert('请输入类目参数！');
      }
    },
    // 方法用于触发长图文件输入框的点击事件，原理同'triggerFileInput'方法，只是针对长图的文件输入框（假设存在名为'fileInputLong'的长图文件输入框引用）
    triggerLongImageInput() {
      this.$refs.fileInputLong.click();
    },
    // 处理长图文件选择变化的事件方法，功能与'handleFileChange'类似，但针对长图文件进行操作，将长图文件转换为DataURL后保存到'detailImages'数组，并将文件对象保存到'longImageFiles'数组
    handleLongImageChange(event) {
      const files = Array.from(event.target.files);
      files.forEach(file => {
        const reader = new FileReader();
        reader.onload = (e) => {
          this.detailImages.push(e.target.result); // 保存 DataURL 用于前端显示
        };
        reader.readAsDataURL(file); // 读取长图为 DataURL
      });
      this.longImageFiles.push(...files); // 存储长图文件对象，用于上传
    },
    // 异步方法用于上传文件（可以是商品图片或者长图），接收要上传的文件数组和文件类型标识（'images'表示商品图片，'longimages'表示长图）作为参数
    async uploadFiles(files, type) {
      const formData = new FormData();
      files.forEach(file => {
        formData.append('files', file); // 将文件添加到 FormData 中
      });

      try {
        // 判断上传的是商品图片还是长图
        const uploadUrl = type === 'images'
          ? 'http://localhost:3000/upload-images'
          : 'http://localhost:3000/upload-long-image';

        const response = await axios.post(uploadUrl, formData, {
          headers: {
            'Content-Type': 'multipart/form-data',
          },
        });

        if (response.data.success) {
          // 根据类型返回相应的路径
          if (type === 'images') {
            return response.data.imagePaths; // 返回商品图片的路径
          } else {
            return response.data.longImagePaths; // 返回长图的路径
          }
        } else {
          alert('图片上传失败，请重试！');
          return [];
        }
      } catch (error) {
        console.error('图片上传失败:', error);
        alert('图片上传失败，请稍后再试！');
        return [];
      }
    },
    // 异步方法用于提交整个商品信息到服务器，包括商品名称、价格、类目、详细描述以及相关图片路径等信息
    async submitProduct() {
  const formData = new FormData();
  formData.append('productName', this.productName);
  formData.append('productPrice', this.productPrice);
  formData.append('detail', this.detail);
  formData.append('categoryParams', JSON.stringify(this.categories));
  
  // 将商品详细描述信息按行分割，去除每行的空白字符，过滤掉空行后转换为JSON字符串，添加到formData中
  const detailLines = this.detail.split('\n').map(line => line.trim()).filter(line => line.length > 0);
  formData.append('detailLines', JSON.stringify(detailLines));

  // 调用'uploadFiles'方法分别上传商品图片和长图，并获取返回的图片路径信息
  const imagePaths = await this.uploadFiles(this.imageFiles, 'images');
  const longImagePaths = await this.uploadFiles(this.longImageFiles, 'longimages');

  // 将获取到的商品图片路径和长图路径信息转换为JSON字符串后添加到formData中
  formData.append('imagePaths', JSON.stringify(imagePaths));
  formData.append('longImagePaths', JSON.stringify(longImagePaths));

  // 打印formData的内容，方便调试查看每个字段及其对应的值
  for (let pair of formData.entries()) {
    console.log(pair[0] + ': ' + pair[1]);  // 输出每一个字段及其对应的值
  }

  try {
    const response = await axios.post('http://localhost:3000/submit-product', formData, {
      headers: { 'Content-Type': 'multipart/form-data' }
    });

    console.log(response.data);  // 你可以在这里查看服务器的响应

    if (response.data.success) {
      alert(response.data.message);
    } else {
      alert('提交失败，请稍后再试！');
    }
  } catch (error) {
    console.error('提交失败:', error);
    alert('提交失败，请稍后再试！');
  }
}


  },
};

</script>
