<template>
    <div class="w">
      <div class="header">
        <div class="logo">
          <a @click="checkHome">
            <img :src="logoImage" alt="Logo">
          </a>
        </div>
      </div>
      <div class="registerarea">
        <h3>
          注册新用户
          <em>
            我有账号，去<a @click="checkHome">登录</a>
          </em>
        </h3>
        <div class="reg_form">
          <form @submit.prevent="handleSubmit">
            <ul>
              <li>
                <label for="role">角色:</label>
                <select class="inp" id="role" v-model="role">
                  <option value="user">用户</option>
                  <option value="admin">商家</option>
                </select>
              </li>
              <li>
                <label for="email">邮箱:</label>
                <input type="email" class="inp" id="email" v-model="email" required>
              </li>
              <li>
                <label for="nickname">昵称:</label>
                <input type="text" class="inp" id="nickname" v-model="nickname" required>
              </li>
              <li>
                <label for="pwd">登陆密码:</label>
                <input type="password" class="inp" id="pwd" v-model="password" required>
              </li>
              <li class="safe">
                安全程度
                <em class="ruo">弱</em>
                <em class="zhong">中</em>
                <em class="qiang">强</em>
              </li>
              <li>
                <label for="surepwd">确认密码:</label>
                <input type="password" class="inp" id="surepwd" v-model="confirmPassword" required>
              </li>
              <li class="agree">
                <input type="checkbox" v-model="agree" required>同意协议并注册
                <a href="#">《知果果用户协议》</a>
              </li>
              <li>
                <input type="submit" value="完成注册" class="over">
              </li>
            </ul>
          </form>
        </div>
      </div>
      <div class="footer">
        <p class="links">
          关于我们 | 联系我们 | 联系客服 | 商家入驻 | 营销中心 | 手机品优购 | 友情链接 | 销售联盟 | 品优购社区 | 品优购公益 | English Site | Contact U
        </p>
        <p class="copyright">
          地址：北京市昌平区建材城西路金燕龙办公楼一层 邮编：114514 电话：15159791232 传真：010-82935100 邮箱: 1801333677@qq.com <br>
          京ICP备08001421号京公网安备110108007702
        </p>
      </div>
    </div>
  </template>
  
  <script>
  import '@/assets/zhuce/css/base.css';
  import '@/assets/zhuce/css/register.css';
  
  export default {
    name: 'ZhuceView',
    data() {
      return {
        email: '',
        nickname: '',
        password: '',
        confirmPassword: '',
        role: 'user', // 默认选中"用户"
        agree: false, // 用户同意协议
      };
    },
    methods: {
      // 方法用于处理跳转到首页的逻辑，通过Vue Router将页面导航到名为'home'的路由对应的页面
      checkHome() {
        this.$router.push({ name: 'home' });
      },
      handleSubmit() {
        // 简单的前端验证
        // 进行简单的前端验证逻辑，首先检查两次输入的密码是否一致
        if (this.password !== this.confirmPassword) {
          alert("密码不一致！");
          return;
        }
  
        if (!this.agree) {
          alert("请同意协议！");
          return;
        }
  
        // 创建一个 XMLHttpRequest 对象，用于向服务器发送HTTP请求，实现注册功能与服务器进行交互
        const xhr = new XMLHttpRequest();
        // 根据用户选择的角色（'user' 或 'admin'）来确定要发送注册请求的服务器接口URL
        const url = this.role === 'user' ? "http://localhost:3000/api/register/user" : "http://localhost:3000/api/register/admin";

        // 初始化请求，设置请求方法为'POST'（用于提交数据），指定请求的URL以及设置请求为异步（第三个参数为 true）
        xhr.open("POST", url, true);
        xhr.setRequestHeader("Content-Type", "application/json");
  
        // 注册事件处理函数，当请求的状态发生改变时会触发该函数，用于处理服务器的响应情况
        xhr.onreadystatechange = () => {
          if (xhr.readyState === 4) {
            if (xhr.status === 200) {
              alert("注册成功！");
              this.$router.push({ name: 'enter' }); // 假设登录页的路由名称是'login'
            } else {
              alert("注册失败！请重试。");
            }
          }
        };
  
        // 构造要发送给服务器的注册信息数据，将相关数据属性转换为JSON格式的字符串
        const data = JSON.stringify({
          email: this.email,
          nickname: this.nickname,
          password: this.password,
          role: this.role,
        });
  
        xhr.send(data);
      },
    },
  };
  </script>
  