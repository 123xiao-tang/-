import { fileURLToPath, URL } from 'node:url'

import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'
import vueDevTools from 'vite-plugin-vue-devtools'

// 使用 defineConfig 函数定义 Vite 项目的配置对象，并将其作为默认导出，方便在项目启动时被 Vite 识别和应用配置内容
export default defineConfig({
  plugins: [
    vue(),
    vueDevTools(),
  ],
  resolve: {
    alias: {
      // 将 '@' 定义为一个别名，它通过 fileURLToPath 和 URL 函数组合来指定实际对应的路径，
      // 这里表示项目源代码目录（通常是 'src' 目录）的路径，
      // 例如在项目代码中使用 import SomeComponent from '@/components/SomeComponent.vue';
      // 时，Vite 会将其解析为实际的 './src/components/SomeComponent.vue' 路径
      '@': fileURLToPath(new URL('./src', import.meta.url))
    },
  },
})